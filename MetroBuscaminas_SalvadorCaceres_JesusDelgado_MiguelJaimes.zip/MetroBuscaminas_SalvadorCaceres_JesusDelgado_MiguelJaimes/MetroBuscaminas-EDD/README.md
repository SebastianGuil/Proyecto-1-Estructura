El README original está en el archivo ZIP del proyecto, gracias.
