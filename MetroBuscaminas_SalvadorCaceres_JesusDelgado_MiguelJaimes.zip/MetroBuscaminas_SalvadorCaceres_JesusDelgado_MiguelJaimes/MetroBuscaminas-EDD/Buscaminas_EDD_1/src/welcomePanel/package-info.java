/**
 * Este paquete contiene la interfaz gráfica ventana de bienvenida del juego.
 * Donde se piden los parámetros.
 */
package welcomePanel;