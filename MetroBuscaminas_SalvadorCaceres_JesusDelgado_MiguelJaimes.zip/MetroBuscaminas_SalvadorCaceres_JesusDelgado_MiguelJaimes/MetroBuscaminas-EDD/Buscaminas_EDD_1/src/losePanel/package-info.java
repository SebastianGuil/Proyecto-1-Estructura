/**
 * Este paquete abarca la interfaz gráfica que se muestra cuando el jugador pierde el juego.
 * Incluye un panel con un mensaje de derrota e incluye la opción de reiniciar.
 */
package losePanel;
