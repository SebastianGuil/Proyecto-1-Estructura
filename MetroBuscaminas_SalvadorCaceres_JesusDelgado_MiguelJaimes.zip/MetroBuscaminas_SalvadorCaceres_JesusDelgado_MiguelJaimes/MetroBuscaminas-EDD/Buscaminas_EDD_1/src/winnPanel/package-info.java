/**
 * Este paquete incluye la interfaz gráfica que se muestra cuando el jugador gana el juego.
 * Tiene un panel con un mensaje de victoria y opción de reiniciar.
 */
package winnPanel;
