# MetroBuscaminas_SalvadorCaceres_JesusDelgado_MiguelJaimes
# Buscaminas-EDD-P1

El siguiente Proyecto es una creación por alumnos de la materia Estructura de Datos. Este código te permite jugar y crear partidas a tu antojo desde una interfaz creada.
A la vez puedes guardar tu progreso y retomar la partida cuando desees.

El Javadoc está creado dentro del archivo "dist". El zip hay que descomprimirlo y presionar el archivo llamado index.html

Dirección de Repositorio Github: https://github.com/Salvi2/Buscaminas-EDD-P1.git
token: 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

Integrantes:
1) Salvador Cáceres 30360977
2) Jesús Delgado 30730387
3) Miguel Jaimes 30773572
